import boto3

def lambda_handler(event, context):
	print("This event is being tested")
	print(event)
	return {'Status': 'Lambda is updated'}